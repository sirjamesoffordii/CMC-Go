import { Person } from "../../drizzle/schema";
import { User, Edit2 } from "lucide-react";
import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { useState } from "react";

interface PersonIconProps {
  person: Person;
  onStatusChange: (personId: string, newStatus: "Yes" | "Maybe" | "No" | "Not Invited") => void;
  onClick: (person: Person) => void;
  onEdit?: (person: Person) => void;
}

const STATUS_COLORS = {
  "Yes": "text-green-500",
  "Maybe": "text-yellow-500",
  "No": "text-red-500",
  "Not Invited": "text-gray-400",
};

export function PersonIcon({ person, onStatusChange, onClick, onEdit }: PersonIconProps) {
  const [isHovered, setIsHovered] = useState(false);
  
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: person.personId });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  const firstName = person.name.split(' ')[0];
  const truncatedName = firstName.length > 7 ? firstName.slice(0, 7) + '.' : firstName;

  const handleStatusClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    const STATUS_CYCLE: Array<"Yes" | "Maybe" | "No" | "Not Invited"> = [
      "Not Invited",
      "Yes",
      "Maybe",
      "No",
    ];
    const currentIndex = STATUS_CYCLE.indexOf(person.status);
    const nextIndex = (currentIndex + 1) % STATUS_CYCLE.length;
    const nextStatus = STATUS_CYCLE[nextIndex];
    onStatusChange(person.personId, nextStatus);
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="relative group/person flex flex-col items-center w-[50px] cursor-grab active:cursor-grabbing"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      {...attributes}
      {...listeners}
    >
      {/* First Name Label with Edit Button */}
      <div className="relative flex items-center justify-center mb-1 group/name">
        <div className="text-xs text-gray-600 font-medium text-center">
          {truncatedName}
        </div>
        {onEdit && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onEdit(person);
            }}
            className="absolute -top-1 -right-2 opacity-0 group-hover/name:opacity-100 transition-opacity p-0.5 hover:bg-gray-100 rounded"
            title="Edit person"
          >
            <Edit2 className="w-3 h-3 text-gray-500" />
          </button>
        )}
      </div>

      <div className="relative">
        <button
          onClick={handleStatusClick}
          className="relative transition-all hover:scale-110 active:scale-95"
        >
          {/* Gray spouse icon behind - shown when person has spouse */}
          {person.spouse && (
            <User
              className="w-10 h-10 text-gray-300 absolute top-0 left-3 pointer-events-none"
              strokeWidth={1.5}
              fill="currentColor"
            />
          )}
          {/* Main person icon */}
          <User
            className={`w-10 h-10 ${STATUS_COLORS[person.status]} transition-colors cursor-pointer relative z-10`}
            strokeWidth={1.5}
            fill="currentColor"
          />
        </button>

        {/* Role Label - Absolutely positioned, shown on hover */}
        {person.primaryRole && (
          <div className="absolute top-full left-1/2 -translate-x-1/2 mt-1 text-xs text-gray-500 text-center max-w-[80px] leading-tight opacity-0 group-hover/person:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
            {person.primaryRole}
          </div>
        )}
      </div>
    </div>
  );
}


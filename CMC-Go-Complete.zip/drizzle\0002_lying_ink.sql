ALTER TABLE `districts` ADD `leftNeighbor` varchar(64);--> statement-breakpoint
ALTER TABLE `districts` ADD `rightNeighbor` varchar(64);